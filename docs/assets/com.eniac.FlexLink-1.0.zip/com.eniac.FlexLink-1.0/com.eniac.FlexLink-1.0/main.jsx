var sequence_changed = false;
var sequence_thumb_exported = false;

if (typeof ($) == 'undefined') {
    $ = {};
}

$.FlexLink = {
    registerActiveSequenceChanged: function () {
        var success = app.bind("onActiveSequenceChanged", $.FlexLink.onActiveSequenceChanged);
    },
    onActiveSequenceChanged: function () {
        sequence_changed = true;
    },
    onExportSeqThumbnailComplete: function (jobID, outputFilePath) {
        sequence_thumb_exported = true;
    },
    getSequenceChanged: function () {
        return sequence_changed ? 1 : 0;
    },
    clearSequenceChanged: function () {
        sequence_changed = false;
    },
    getSequenceThumbExported: function () {
        return sequence_thumb_exported ? 1 : 0;
    },
    clearSequenceThumbExported: function () {
        sequence_thumb_exported = false;
    },
    exportSeqThumbnail: function (presetPath, outputPath) {
        var seq = app.project.activeSequence;
        if (seq) {
            app.encoder.bind('onEncoderJobComplete', $.FlexLink.onExportSeqThumbnailComplete);
            app.encoder.encodeSequence(seq,
                outputPath,
                presetPath,
                app.encoder.ENCODE_ENTIRE,
                1,
                true);
        }
        return parseInt(parseInt(app.project.activeSequence.end) / 254016000);
    },
    getTrackTimes: function (track) {
        var times = [];
        for (var i = 0; i < track.clips.length; i++) {
            var clip = track.clips[i];
            var start = clip.start.seconds * 1000;
            var end = clip.end.seconds * 1000;
            var label = clip.projectItem.getColorLabel(); // 获取标签颜色
            times.push({
                start: parseInt(start),
                end: parseInt(end),
                color: label
            });
        }
        return times;
    },
    getAllVideoTrackTimes: function () {
        var sequence = app.project.activeSequence;
        var result = {
            tracks: [],
            end: parseInt(parseInt(sequence.end) / 254016000)
        }
        for (var j = 0; j < sequence.videoTracks.length; j++) {
            var track = sequence.videoTracks[j];
            if (!track.clips.length) {
                continue;
            }
            var trackTimes = $.FlexLink.getTrackTimes(track);
            result.tracks.push({
                video_track: j,
                clips: trackTimes
            });
        }
        // for (var j = 0; j < sequence.audioTracks.length; j++) {
        //     var track = sequence.audioTracks[j];
        // 	if (!track.clips.length) {
        // 		continue;
        // 	}
        //     var trackTimes = getTrackTimes(track);
        //     result.tracks.push({
        //         audio_track: j,
        //         clips: trackTimes
        //     });
        // }
        return JSON.stringify(result);
    },
    setTime: function (timePct) {
        var sequence = app.project.activeSequence;
        sequence.setPlayerPosition((timePct * parseInt(sequence.end)).toString());
    },
    debug: function () {
        $.FlexLink.exportSeqThumbnail('C:\\Users\\tongy\\Desktop\\test\\JPEG_H60_Thumbnail.epr', "C:\\Users\\tongy\\Desktop\\test\\thumbnail\\")
    }
}