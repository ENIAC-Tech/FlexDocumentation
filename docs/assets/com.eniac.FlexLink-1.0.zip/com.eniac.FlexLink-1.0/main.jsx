var sequence_changed = false;
var sequence_thumb_exported = false;

if (typeof ($) == 'undefined') {
    $ = {};
}

function flexLinkEscapeString(value) {
    return '"' + String(value)
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n')
        .replace(/\t/g, '\\t') + '"';
}

function flexLinkStringify(value) {
    if (typeof JSON !== 'undefined' && JSON && typeof JSON.stringify === 'function') {
        return JSON.stringify(value);
    }
    if (value === null) {
        return 'null';
    }
    var valueType = typeof value;
    if (valueType === 'string') {
        return flexLinkEscapeString(value);
    }
    if (valueType === 'number') {
        return isFinite(value) ? String(value) : 'null';
    }
    if (valueType === 'boolean') {
        return value ? 'true' : 'false';
    }
    if (valueType === 'undefined' || valueType === 'function') {
        return 'null';
    }
    if (value instanceof Array) {
        var items = [];
        for (var i = 0; i < value.length; i++) {
            items.push(flexLinkStringify(value[i]));
        }
        return '[' + items.join(',') + ']';
    }

    var parts = [];
    for (var key in value) {
        if (value.hasOwnProperty(key)) {
            parts.push(flexLinkEscapeString(key) + ':' + flexLinkStringify(value[key]));
        }
    }
    return '{' + parts.join(',') + '}';
}

$.FlexLink = {
    registerActiveSequenceChanged: function () {
        var success = app.bind("onActiveSequenceChanged", $.FlexLink.onActiveSequenceChanged);
    },
    onActiveSequenceChanged: function () {
        sequence_changed = true;
    },
    onExportSeqThumbnailComplete: function (jobID, outputFilePath) {
        sequence_thumb_exported = true;
    },
    getSequenceChanged: function () {
        return sequence_changed ? 1 : 0;
    },
    clearSequenceChanged: function () {
        sequence_changed = false;
    },
    getSequenceThumbExported: function () {
        return sequence_thumb_exported ? 1 : 0;
    },
    clearSequenceThumbExported: function () {
        sequence_thumb_exported = false;
    },
    exportSeqThumbnail: function (presetPath, outputPath) {
        var seq = app.project.activeSequence;
        if (!seq) {
            return flexLinkStringify({
                error: true,
                code: 'NO_ACTIVE_SEQUENCE',
                message: '没有活动序列，无法导出缩略图'
            });
        }
        app.encoder.bind('onEncoderJobComplete', $.FlexLink.onExportSeqThumbnailComplete);
        app.encoder.encodeSequence(seq,
            outputPath,
            presetPath,
            app.encoder.ENCODE_ENTIRE,
            1,
            true);
        return String(parseInt(parseInt(seq.end) / 254016000));
    },
    getTrackTimes: function (track) {
        var times = [];
        var clipCount = track.clips.numItems;
        for (var i = 0; i < clipCount; i++) {
            var clip = track.clips[i];
            var start = clip.start.seconds * 1000;
            var end = clip.end.seconds * 1000;
            var label = -1;
            var pi = clip.projectItem;
            if (pi && typeof pi.getColorLabel === 'function') {
                label = pi.getColorLabel();
            }
            times.push({
                start: parseInt(start),
                end: parseInt(end),
                color: label
            });
        }
        return times;
    },
    getAllVideoTrackTimes: function () {
        try {
            var sequence = app.project.activeSequence;
            if (!sequence) {
                return flexLinkStringify({
                    error: true,
                    code: 'NO_ACTIVE_SEQUENCE',
                    message: '没有活动序列，请在时间轴打开一个序列后再试',
                    tracks: [],
                    end: 0
                });
            }
            var result = {
                error: false,
                tracks: [],
                end: parseInt(parseInt(sequence.end) / 254016000)
            };
            var trackCount = sequence.videoTracks.numTracks;
            for (var j = 0; j < trackCount; j++) {
                var track = sequence.videoTracks[j];
                if (!track.clips.numItems) {
                    continue;
                }
                var trackTimes = $.FlexLink.getTrackTimes(track);
                result.tracks.push({
                    video_track: j,
                    clips: trackTimes
                });
            }
            return flexLinkStringify(result);
        } catch (e) {
            return flexLinkStringify({
                error: true,
                code: 'EXCEPTION',
                message: String(e && e.message ? e.message : e),
                line: e && e.line ? e.line : 0,
                name: e && e.name ? e.name : '',
                tracks: [],
                end: 0
            });
        }
    },
    setTime: function (timePct) {
        var sequence = app.project.activeSequence;
        if (!sequence) {
            return flexLinkStringify({
                error: true,
                code: 'NO_ACTIVE_SEQUENCE',
                message: '没有活动序列，无法设置播放位置'
            });
        }
        sequence.setPlayerPosition((timePct * parseInt(sequence.end)).toString());
        return flexLinkStringify({ ok: true });
    },
    debug: function () {
        $.FlexLink.exportSeqThumbnail('C:\\Users\\tongy\\Desktop\\test\\JPEG_H60_Thumbnail.epr', "C:\\Users\\tongy\\Desktop\\test\\thumbnail\\")
    }
};